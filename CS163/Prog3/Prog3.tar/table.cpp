//Yutong Hu
//08/01/18
//program3
//This program to build a hash table to help
//user to choose the item that they want

#include "table.h"
using namespace std;

table::table(int size) //constructor
{
	hash_table_size = size;
	hash_table = new node *[hash_table_size];
	node ** current = hash_table;
	node ** end = (hash_table +size);
	while(current != end)
	{
		*current = NULL;
		++current;

	} 

}

table::~table() //destructor
{
	for(int i=0;i<hash_table_size;++i)
	{
		node *current = hash_table[i];
		while(current)
		{
			node *temp = current->next;
			delete current;
			current = temp;

		}

	}
	delete [] hash_table;

}

int table::hash_function(char *key)const //build the hash function
{
	return (key[0]*2)%hash_table_size;
}
int table::insert() //let user enter the item
{
	node *current = new node;
	current->information.create_info();
	int key = hash_function(current->information.get_name());  

	if(key>hash_table_size-1 || key<0)
		return 0;

	if(hash_table[key] == NULL)
	{
		hash_table[key] = current;
		current->next = NULL;
	}

	else
	{
		current->next = hash_table[key];
		hash_table[key] = current;
	}

           return 1;

}
int table::retrieve(char *to_find) //retrieve
{
	int key = hash_function(to_find);
	if(key>hash_table_size-1 || key<0)
		return 0;

	node *current = hash_table[key];

	while(current)
	{
		if(current->information.retrieve(to_find))
			return 1;
		current = current->next;
	}
	return 1; 
}

int table::display(char *to_dis) //display the information
{
	int key = hash_function(to_dis);
	if(key>hash_table_size-1 || key<0)
		return 0;

	node *current = hash_table[key];

	while(current)
	{
		if(current->information.display())
			return 1;
		current = current->next;
	}
	return 1; 
}

int table::display_all() //display all the information
{
	for(int i=0;i<hash_table_size;++i)
	{
		if(hash_table[i])
		{
			node *current = hash_table[i];
			while(current)
			{
				current->information.display();
				current = current->next;
			}
		}

	}
	return 1;

}

int table::remove(char * to_re) //remove
{
	int key = hash_function(to_re);
	if(key>hash_table_size-1 || key<0)
		return 0;

	node *current = hash_table[key];

	while(current)
	{
		node *temp = current->next;
		delete current;
		current = temp;
	}
	return 1; 
}
/*int table::hash_function(char *key)const
{
	return (key[0]*2)%hash_table_size;
}*/

int table::read_info() //read the information from file
{
	ifstream find;
	find.open("shopping.txt");

	if(!find)
		return 0;

	else
	{
		node *current = new node;
		current->next = NULL;

			char read1[SIZE];
		find.get(read1,SIZE,'|');
		find.ignore(100,'|');     
		current->information.name = new char[strlen(read1)+1];
		strcpy(current->information.name,read1);

		char read2[SIZE];
		find.get(read2,SIZE,'|');
		find.ignore(100,'|');     
		current->information.describe = new char[strlen(read2)+1];
		strcpy(current->information.describe,read2);

		char read3[SIZE];
		find.get(read3,SIZE,'|');
		find.ignore(100,'|');     
		current->information.size = new char[strlen(read3)+1];
		strcpy(current->information.size,read3);

		char read4[SIZE];
		find.get(read4,SIZE,'\n');
		find.ignore(100,'\n');     
		current->information.web = new char[strlen(read4)+1];
		strcpy(current->information.web,read4);

		int key = hash_function(current->information.get_name());
		hash_table[key] = current;

		while(find.peek()!=EOF)
		{
			node *current = new node;
			current->next = NULL;

			char read1[SIZE];
			find.get(read1,SIZE,'|');
			find.ignore(100,'|');     
			current->information.name = new char[strlen(read1)+1];
			strcpy(current->information.name,read1);

			char read2[SIZE];
			find.get(read2,SIZE,'|');
			find.ignore(100,'|');     
			current->information.describe = new char[strlen(read2)+1];
			strcpy(current->information.describe,read2);

			char read3[SIZE];
			find.get(read3,SIZE,'|');
			find.ignore(100,'|');     
			current->information.size = new char[strlen(read3)+1];
			strcpy(current->information.size,read3);

			char read4[SIZE];
			find.get(read4,SIZE,'\n');
			find.ignore(100,'\n');     
			current->information.web = new char[strlen(read4)+1];
			strcpy(current->information.web,read4);
			
			int key = hash_function(current->information.get_name());
			node *temp = hash_table[key];
		 	if(temp == NULL)
				hash_table[key] = current;
			else
			  {
				current->next = temp;
				hash_table[key] = current;
			  }	
		}
		find.close();
		return 1;
	}


}













