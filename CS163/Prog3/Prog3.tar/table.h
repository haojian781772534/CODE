//Yutong Hu
//08/01/18
//program3
//This program to build a hash table to help
//user to choose the item that they want

#include "info.h"
#include <iostream>
#include <cctype>
#include <cstring>
#include <fstream>

struct node //node structure
{
   info information;
   node *next;

};


class table
{
  
 public:

   table(int size=5);
   ~table();
   int hash_function(char *key)const;
   int insert(); //add the infor in the hash table
   int retrieve(char *); //retrieve
   int display(char *); //display what the user want
   int display_all(); //display all
   int remove(char *); //remove
   int read_info();//read the info from file

 private:

   node **hash_table;

   int hash_table_size;




};
