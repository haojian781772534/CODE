//Yutong Hu
//08/01/18
//program3
//This program to build a hash table to help
//user to choose the item that they want

#include "table.h"
using namespace std;

int main()
{

   table a_table;
  // let user enter the number that they want to choose
   int response1 = 0;
   char response2; //let user enter Y/N

   
    if(a_table.read_info() == 0) //read the info from file
      cout << "Can't open the file!" << endl;

    else
     {
        do
	 {
           cout << "Please choose what you want to do: " << endl;
           cout << "1. Add a new item in the hash table " << endl;
           cout << "2. Retrieve information about the item " << endl;
           cout << "3. Remove an item " << endl;
           cout << "4. Display the item you want " << endl;
           cout << "5. Display " << endl;

  	   cin >> response1;
           cin.ignore(100,'\n');

	   if(response1 == 1)
		{
		    if(a_table.insert()) //function call
			cout << "Add successfully!" << endl;
		    else
			cout << "NOT successful!" << endl;
		}

	   else if(response1 == 2)
		{
		    char item1[SIZE];
		    cout << "Please enter the item that you want to retrieve: " << endl;
		    cin.get(item1,SIZE,'\n'); //give the value
		    cin.ignore(100,'\n');
		    if(a_table.retrieve(item1)) //function call
			{
			   cout << "You find that!" << endl;
			   a_table.display(item1); //function call
			   cout << endl;
			}
		    else
			cout << "Cannot find it" << endl;
		}
	    else if(response1 == 3)
		{
	            char item2[SIZE]; //match
		    cout << "Please enter the item that you want to remove: " << endl;
		    cin.get(item2,SIZE,'\n');
		    cin.ignore(100,'\n');
 		    if(a_table.remove(item2)) //function call
			cout << "Remove successfully!" << endl;
		    else
			cout << "NOT successful!" << endl;

		}
	    
	    else if(response1 == 4)
		{
		    char item3[SIZE]; //match
		    cout << "Please enter the item that you want to display: " << endl;
		    cin.get(item3,SIZE,'\n');
		    cin.ignore(100,'\n');
		    a_table.display(item3); //function call
		}
	    else if(response1 == 5)
		{
	 	   a_table.display_all(); //function call
		}
	    else
		cout << "Please enter the right number!" << endl;

	
	    cout << "Do you want to do it again? Y/N" << endl;
	    cin >> response2;
	    cin.ignore(100,'\n');
	 }while(response2 == 'y' || response2 == 'Y');
     }


    return 0;
}
