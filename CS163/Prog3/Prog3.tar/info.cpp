//Yutong Hu
//08/01/18
//program3
//This program to build a hash table to help
//user to choose the item that they want

#include "info.h"
using namespace std;



info::info() //constructor to initialization all data
{
	name = NULL;
	describe = NULL;
	size = NULL;
	web = NULL;
}

info::~info() //destructor
{
	if(name)
	{
		delete [] name;
		name = NULL;
	}
	if(describe)
	{
		delete [] describe;
		describe = NULL;
	}
	if(size)
	{
		delete [] size;
		size = NULL;
	}
	if(web)
	{
		delete []web;
		web = NULL;
	}

}

int info::create_info() //to create the information from user
{
	char info1[SIZE];
	cout << "Please enter the name: " << endl; 
	cin.get(info1,SIZE,'\n');
	cin.ignore(100,'\n');
	name = new char[strlen(info1)+1];
	strcpy(name,info1);


	char info2[SIZE];
	cout << "Please enter the description: " << endl;
	cin.get(info2,SIZE,'\n');
	cin.ignore(100,'\n');
	describe = new char[strlen(info2)+1];
	strcpy(describe,info2);

	char info3[SIZE];
	cout << "Please enter the size: " << endl; 
	cin.get(info3,SIZE,'\n');
	cin.ignore(100,'\n');
	size = new char[strlen(info3)+1];
	strcpy(size,info3);

	char info4[SIZE];
	cout << "Please enter the website that you find the information: " << endl; 
	cin.get(info4,SIZE,'\n');
	cin.ignore(100,'\n');
	web = new char[strlen(info4)+1];
	strcpy(web,info4);

	return 1;
}

int info::display() //display
{
	cout << "The name is: " << this->name << endl;
	cout << "The description is: " << this->describe << endl;
	cout << "The size is: " << this->size << endl;
	cout << "The website is: " << this->web << endl;

	return 1;

}

int info::retrieve(char *to_find)  //retrueve the information
{
	if(strcmp(to_find,name))
		return 1;
	else
		return 0;

}

char * info::get_name() //get the value about name
{
	return name;
}
