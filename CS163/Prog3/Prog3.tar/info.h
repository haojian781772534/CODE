//Yutong Hu
//08/01/18
//program3
//This program to build a hash table to help
//user to choose the item that they want

#include <iostream>
#include <cctype>
#include <cstring>
#include <fstream>

#define SIZE 150

class info //build a class to save the information from user
{
   public:
       
     	info();
        ~info();
        int create_info();
        int display();
        int retrieve(char *);
        char *get_name();

 	char *name;
	char *describe;
	char *size;
 	char *web;

};
