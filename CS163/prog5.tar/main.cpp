//Yutong Hu
//08/16/18
//prog5
//This program by using a graph to find the city
//and the way that they want

#include "graph.h"
#define SIZE 30
using namespace std;

int main()
{
   graph a_graph; //declare the graph
   int response1=0;
   char response2;
   //use do-while loop to let user choose if they want to do this program again
   do
   {
        cout << "Please choose what you want" << endl;
        cout << "1.Enter vertex" << endl;
        cout << "2.Please enter the road about these two city: " << endl;
        cout << "3.Please enter the city you want to go: " << endl;

        cin >> response1;
        cin.ignore(100,'\n');

        if(response1 == 1)
          {
              cout << "Please enter the vertices that in the graph: "<< endl;
              char vertex1[SIZE];
              cin.get(vertex1,SIZE,'\n');
              cin.ignore(100,'\n');

              int i=0;
              i = a_graph.insert_vertex(vertex1); //function call
              if(i==1)
                   cout << "Insert vertex successfully!" << endl;
              else
                   cout << "Not successful!" << endl;

          }
         else if(response1 == 2)
          {
              cout << "Please enter the first city name: " << endl;
              char name1[SIZE],name2[SIZE];
              cin.get(name1,SIZE,'\n');
              cin.ignore(100,'\n');

              cout << "Please enter the second city name: " << endl;
              cin.get(name2,SIZE,'\n');
              cin.ignore(100,'\n');

              int j=0;
              j = a_graph.insert_edge(name1,name2); //function call
              if(j==1)
                  cout << "Insert edge succussfully!" << endl;
              else
                  cout << "Not successful" << endl;
          }

         else if(response1 == 3)
          {
            char vertex2[SIZE];
            cout << "Please enter the city you want to check: " << endl; 
            cin.get(vertex2,SIZE,'\n');
            cin.ignore(100,'\n');
            a_graph.display_all(vertex2); //function call
          }


          cout << "Do you want to do it again?  Y/N" << endl;
          cin >> response2;
          cin.ignore(100,'\n');



   }while(response2 == 'y' || response2 == 'Y');  


   return 0;
}














