//Yutong Hu
//08/16/18
//prog5
//This program by using a graph to find the city
//and the way that they want

#include "graph.h"
using namespace std;

graph::graph(int size) //constructor
{
    adjacency_list = new vertex [size];

    for(int i=0;i<size;++i)
      {
          adjacency_list[i].head = NULL;
          adjacency_list[i].cityname = NULL;

      }
    list_size = size;
  
  
}

graph::~graph() //destructor
{
   for(int i=0;i<list_size;++i)
     {
       delete [] adjacency_list[i].cityname;
       adjacency_list[i].cityname = NULL;
       adjacency_list[i].head = NULL;

     }

}

int graph::insert_vertex(char *to_add) //insert the the vertex
{
   int i=0;

   while(adjacency_list[i].cityname)
     {
	if(i==5)
           return 0;

        ++i;
     } 
    adjacency_list[i].cityname = new char [strlen(to_add)+1];
    strcpy(adjacency_list[i].cityname,to_add);

    adjacency_list[i].head = NULL;
    return 1;

}

int graph::insert_edge(char *current_vertex,char *to_attach) //insert the edge
{
   if(!adjacency_list[0].cityname)
      return 0;
   int connection1 = find_location(current_vertex);
   int connection2 = find_location(to_attach);
   node *current = new node;

   current->adjacent = &adjacency_list[connection2];
   current->next = adjacency_list[connection1].head;
   adjacency_list[connection1].head = current;
   return 1;

}

int graph::find_location(char *vertex) //to find the location
{
   for(int i=0;i<list_size;++i)
     {
       if(strcmp(vertex,adjacency_list[i].cityname) == 0)
           return i;
     }

   return -1;


}



int graph::display_all(char *vertex) //display the city that you want to visit
{
   int i=find_location(vertex);
   if(i<0)
     return 0;


   node *temp = adjacency_list[i].head;
   cout << "The vertex's city name is: " << adjacency_list[i].cityname << endl;
  
   while(temp)
    {
	cout << "The edge city name :" << temp->adjacent->cityname << endl;
        temp = temp->next;
    }   
   
   return 1;
  


}



















