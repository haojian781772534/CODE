//Yutong Hu
//08/16/18
//prog5
//This program by using a graph to find the city
//and the way that they want

#include <iostream>
#include <cctype>
#include <cstring>

struct vertex //build a structure which save the vertex
{
   char *cityname;
   struct node *head; 

};

struct node //build a structure about node
{
   vertex *adjacent;
   node *next;

};

class graph  //a class about graph
{
   public:

     graph(int size=5);
     ~graph();
     int insert_vertex(char *);
     int insert_edge(char* ,char*);
     int find_location(char *);
     int display_all(char *);



   private:

    vertex *adjacency_list;
    int list_size;




};
