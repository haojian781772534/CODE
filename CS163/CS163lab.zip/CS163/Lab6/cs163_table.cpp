#include "cs163_table.h"
using namespace std;

/* Implement these three functions for this lab */
table::table(int size)
{
      //Allocate the hash table and initialize each
      //element and data member.
    hash_table = new node * [hash_table_size+1];
    hash_table_size = size;

    for (int a = 0 ; a <= size ; a++)
        hash_table[a] = NULL;
}

//Using a hash function, insert a new value into the 
//head of the chain
int table::insert(char * key_value, const journal_entry & to_add)
{
        //Place your code here
    int key = hash_function(key_value);
    if (key > hash_table_size-1 || key < 0)
        return 0;

    node * curr = new node;
    curr->entry.copy_entry(to_add);
    if (hash_table[key] == NULL)
        curr->next = NULL;
    else
        curr->next = hash_table[key];
    hash_table[key] = curr;

    return 1;
}


//Using a hash function determine which chain to search
//then return 0 if no match is found
int table::retrieve(char * title_to_find, journal_entry & found) const
{
        //Place your code here
    int key = hash_function(title_to_find);
    if (key > hash_table_size-1 || key < 0)
        return 0;

    for ( node * curr = hash_table[key] ; curr ; curr = curr->next) {
        if (curr->entry.retrieve(title_to_find, found))
            return 1;
    }
    return 0;
}


int table::hash_function(char * key_value) const {
    return * key_value * 24 %5;
}
