#include "cs163_bst.h"
using namespace std;


// ***These are sample wrapper functions
table::~table()
{
     remove_all(root); //call the recursive removal_all private function
}


// This is a wrapper function that will call the recursive count function
int table::count()
{
    //Notice how the returned value from the recursive function is used
    return count(root);
}

// Now it is your turn to write the count function recursively
int table::count (node * root)
{
    if (!root)
        return 0;

    if (root->left == NULL && root->right == NULL)
        return 1;

    return (count(root->left) + count(root->right));
}


// Start with the wrapper function that calls the recursive function
int table::sum()
{
    //Call the recursive function here:
    return sum(root);
}

// Now it is your turn to write the sum function recursively
int table::sum (node * root)
{
    if (!root)
        return 0;

    return (sum(root->left) + sum(root->right) + root->data);
}


int table::height()   //simply call the private version of the functions
{
    //Call the recursive function here:
    return height(root);
}

//Now write this function recursively
int table::height (node * root) 
{
    if (!root)
        return 0;

    if (!root->left && !root->right)
        return 1;

    int a = height(root->left);
    int b = height(root->right);
    return (a > b) ? (a+1) : (b+1);
}

int table::remove_all()
{
    //Call the recursive function here:
    return remove_all(root);
}

// Now it is your turn to write the remove_all function recursively
int table::remove_all(node * & root)
{
    if (!root)
        return 0;

    int leftn = remove_all(root->left);
    int rightn = remove_all(root->right);

    if (!root->left && !root->right) {
        delete root;
        root = NULL;
        return leftn + rightn + 1;
    }
    else
        return leftn + rightn;
}  


int table::copy(const table & to_copy)
{
    //Call the recursive function here:
    return copy(root, to_copy.root);
}

// Now it is your turn to write the copy function recursively
int table::copy(node * & dest_root, node * source_root) 
{
    if (!source_root) {
        return 0;
    }

    if (source_root) {
        dest_root = new node;
        dest_root->data = source_root->data;
    }

    int lefta = copy(dest_root->left, source_root->left);
    int righta = copy(dest_root->right, source_root->right);

    return lefta + righta + 1;
}  

//personal text
node * table::successor() {
	return successor(root);
}

node * table::successor(node * root) {
	if (root->right) {
		return tree_min(root->right);
	}

	
}

node * table::tree_min() {
	return tree_min(root);
}

node * table::tree_min(node * root) {
	if (root->left)
		return tree_min(root->left);
	return root;
}

node * table::tree_max() {
	return tree_max(root);
}

node * table::tree_max(node * root) {
	if (root->right)
		return tree_max(root->right);
	return root;
}
