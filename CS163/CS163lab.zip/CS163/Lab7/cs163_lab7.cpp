#include "cs163_bst.h"
using namespace std;

int main()
{
	/*
    table BST;	
    BST.build();
    BST.display();

    cout << "The count of leaf is : " << BST.count() << endl;
    cout << "The sum of tree is : " << BST.sum() << endl;
    cout << "The level of tree is : " << BST.height() << endl;
    cout << "The number of delete is : " << BST.remove_all() << endl;

    table dest;
    table to_copy;
    to_copy.build();
    cout << "The number of copy is : " << dest.copy(BST) << endl;

    cout << "This is 'to_copy' 's display :" << endl;
    BST.display();
    cout << "This is dest display: " << endl;
    dest.display();
    */
	//This is my personal text:
	
	//This use for prove ITA:12.2-8
	

    return 0;
}
