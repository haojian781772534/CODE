#include "cs163_queue.h"


//Implement these functions using a Circular Linked List
//Add at the rear
int queue::enqueue(const journal_entry & to_add)
{
	//Write the function here

    q_node * curr = new q_node;
    curr->entry.copy_entry(to_add);

    if (rear) {
        curr->next = rear->next;
        rear->next = curr;
    }
    else
        curr->next = curr;
    rear = curr;

    return 1;
    //如何return 0?
}


//Remove the node at the front
int queue::dequeue ()
{
	//Write the function here
    if (!rear)
        return 0;

    q_node * dele = rear->next;
    rear->next = rear->next->next;

    if (dele == rear) {
        delete dele;
        rear = NULL;
    }
    else
        delete dele;
    dele = NULL;

    return 1;
}
