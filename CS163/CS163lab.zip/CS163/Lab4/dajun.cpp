// to implement remove all the node.

#include "cs163_queue.h"
#include<iostream>

int queue::remove_entire() {

/*
    int sum = 0;

    if (!rear)
        return 0;
    for (q_node * curr = rear->next; rear->next != rear ; sum++, rear = rear->next) {
        curr = rear->next;
        rear->next = rear->next->next;
        delete curr;
        curr = NULL;
    }
    delete rear;
    rear = NULL;
    ++sum;
*/

    return remove_entire(rear);
}

int queue::remove_entire(q_node * & rear) {
    
    if (rear->next == rear) {
        delete rear;
        rear = NULL;
        return 1;
    }
    else {
        q_node * curr = rear->next;
        rear->next = curr->next;
        delete curr;
        curr = NULL;
        return remove_entire(rear) +1;
    }
}


int queue::count_all() {
/*
    int all = 0;

    for (q_node * curr = rear->next ; curr != rear ; curr = curr->next, ++all);

    return ++all;
*/

    return count_all(rear);
}

int queue::count_all(q_node * rear) {
    if (!rear)
        return 0;

    static q_node * jrear = rear;

    if (rear->next == jrear)
        return 1;
    else 
        return count_all(rear->next) +1;
}
