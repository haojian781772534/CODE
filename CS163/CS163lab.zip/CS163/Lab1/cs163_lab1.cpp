#include "cs163_list.h"
using namespace std;

int main()
{

    //First try this out as is. Then start adding in your function calls!
    list my_list;
    my_list.build();
    my_list.display_all();
    
    list from;
    from.build();
    from.display_all();
    cout << from.copy(from) << endl;

    //PLACE YOUR FUNCTION CALL HERE!

    
    my_list.display_all();
    return 0;    
}
