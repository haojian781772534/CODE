#include "cs163_list.h"
using namespace std;

/*
//Sum  all of the data together in a LLL
int list::sum_total()
{
 	//FIRST do this iteratively here. Then recursively
        //COMMENT out the iterative version when  rewriting
        //the solution recursively

        //To solve this recursively write another
        //and call it from this function
 
    node* curr = head;
    int sum = 0;

    for ( ; curr!=NULL; curr=curr->next)
        sum += curr->data;

    return sum;

    return sum_total(head);
}


//Now implement the function recursively!
int list::sum_total(node * head)
{
    static int sum=0;
    if (head == NULL)
        return sum;
    else {
        sum += head->data;
        return sum_total(head->next);
    }
}
*/

// *************************************************
//Remove the last node in a LLL. Return false if the
//list is empty and nothing is removed

/*
bool list::remove_last()
{
        //Write your code here
 	//FIRST do this iteratively here. Then recursively
        //COMMENT out the iterative version when  rewriting

    
    if (!head)
        return 0;
    
    node * curr = head;
    while (curr->next != tail)
        curr = curr->next;

    tail = curr;
    delete curr->next;
    curr->next = NULL;
    return 1;
    
    return remove_last(head, tail);  
}


//Now implement the function recursively!
bool list::remove_last(node * & head, node * & tail)
{
    if (!head)
        return 0;

    if (head->next == tail) {
        tail = head;
        delete tail->next;
        tail->next = NULL;
        return 1;
    }
    else
        return remove_last(head->next, tail);
}
*/

/*
// ************************************************
//Remove all nodes in a LLL. Remove false if there is
//nothing to remove
bool list::remove_all()
{
        //Remove all nodes in a LLL
 	//FIRST do this iteratively here. Then recursively
        //COMMENT out the iterative version when  rewriting

    
    if (!head)
        return 0;

    node * curr = head;
    for ( ; curr != tail ; curr = head) {
       head = head->next;
       delete curr;
    }
    delete tail;
    tail = head = curr = NULL;
    return 1;
    

    return remove_all(head);
}


//Now implement the function recursively!
bool list::remove_all(node * & head)
{
    if (!head)
        return 0;

    node * curr = head;
    if (head->next != tail) {
        head = head->next;
        delete curr;
        return remove_all(head);
    }
    else {
        delete tail;
        tail = head = curr = NULL;
        return 1;
    }
}


// ************************************************
//Return true if the requested item (sent in as an argument)
//is in the list, otherwise return false

bool list::find_item(int item_to_find)
{
        //Write your code here
    if (!head)
        return 0;
    node * curr = head;
    
    for ( ; curr->next == NULL ; curr = curr->next) {
        if (curr->data == item_to_find)
            return 1;
    }

    return 0;
    
    return find_item(head, item_to_find);
}


//Now implement the function recursively!
bool list::find_item(node * head, int item_to_find)
{
    if (!head)
        return 0;

    if (head->data == item_to_find)
        return 1;
    else
        return find_item(head->next, item_to_find);
}
*/

// ************************************************
//Make a complete copy of a LLL
bool list::copy(list & from)
{
    //Write your code here
    /*
    if (!head)
        return 0;

    for ( ; !head ; head = head->next, from.head = from.head->next) {
        from.head->data = head->data;
        node * curr = new node;
        from.head->next = curr;
    }
    return 1;
    */
    return copy(dest_head, dest_tail, source);
}



//Now implement the function recursively
bool list::copy(node * & dest_head, node * & dest_tail, node * source)
{
    
}
