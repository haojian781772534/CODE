#include "cs163_list.h"
using namespace std;




//Implement these three functions
//Add to the end of the LLL as efficiently as possible
int list::add(journal_entry & to_add)
{
           //Implement this function using the
           //journal entry functions we just wrote!

    node * curr = new node;
    if (head == NULL)
        tail = curr;
    curr->next = head;
    head = curr;
    head->entry.copy_entry(to_add);
    return 1;
}

//Determine if there is a match with the title passed in
//and if so provide the matching journal entry back to the
//client program through the second argument.
//Return a zero if no match is found
int list::find(char matching_title[], journal_entry & found)
{
    //Your code goes here!           

    if (!head)
        return 0;

    for ( node * curr = head ; curr != NULL ; curr = curr->next)
        if (curr->entry.retrieve(matching_title, found)) {
            return 1;
        }

    return 1;
}


//Display all journal entries
//Return false if there are no entries
int list::display(void)
{
    //Your code goes here!
    if (!head)
        return 0;

    node * curr = head;
    for ( ; curr != NULL ; curr = curr->next)
        curr->entry.display();
    return 1;
}


//Copy the list passed in as an argument
//and add the nodes to the end of the current list
int list::append(list & source)
{
        //Your code goes here!
    if (!source.head)
        return 0;

    node * curr = new node;
    curr = source.head;

    for ( ; curr ; curr = curr->next) {
        node * appadd = new node;
        appadd->next = NULL;
        tail->next = appadd;
        appadd->entry.copy_entry(curr->entry);
        tail = appadd;
    }
    curr = NULL;
    return 1;
}
