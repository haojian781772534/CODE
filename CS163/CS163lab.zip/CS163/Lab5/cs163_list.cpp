#include "cs163_list.h"

/* These are the functions you will be implementing */
/* USE RECURSION! */
int insert_after(node * & head)
{
    if (!head)
        return 0;

    if (head->data == 2) {
        node * curr = new node;
        curr->previous = head;
        if (head->next == NULL)
            curr->next = NULL;
        else {
            curr->next = head->next;
            head->next->previous = curr;
        }
        head->next = curr;
        return insert_after(head->next->next) +1;
    }
    else
        return insert_after(head->next);
}


int insert_before(node * & head)
{
    if (!head)
        return 0;

    if (head->data == 2) {
        node * curr = new node;
        if (head->previous == NULL) {
            curr->next = head;
            head = curr;
        }
        else {
            curr->next = head;
            curr->previous = head->previous;
            head->previous->next = curr;
        }
            head->previous = curr;

        return insert_before(head->next->next) +1;
    }
    else
        return insert_before(head->next);
}


int display_last_two(node * head)
{
    if (!head)
        return 0;
    else if (head->next == NULL)
        return head->data;
    else if (head->next->next == NULL)
        return head->data + head->next->data;
    else
        return display_last_two(head->next);
}


int remove_last_two(node * & head)
{
    if (!head || head->next == NULL || head->next->next == NULL)
        return 0;
    else if (head->next->next->next == NULL) {
        head->next = NULL;
        return head->data;
    }
    else
        return head->data + remove_last_two(head->next);
}


//challenge:
bool same_length(node * head1, node * head2)
{
    if (!head1 || !head2) {
        if (!head1 && !head2)
            return 1;
        else
            return 0;
    }
    else
        return same_length(head1->next, head2->next);
}
