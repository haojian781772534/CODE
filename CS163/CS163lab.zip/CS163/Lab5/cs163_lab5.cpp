#include "cs163_list.h"
using namespace std;

int main()
{
    node * head = NULL;
    build(head);
    display(head);

    //PLEASE PUT YOUR CODE HERE to call the function assigned
    //cout << "This change node : " << insert_after(head) << endl;
    //display(head);

    //cout << "This change again : " << insert_before(head) << endl;
    //display(head);

    //cout << "The last two is : " << display_last_two(head) << endl;

    //cout << "The sum except last two is : " << remove_last_two(head) << endl;

    /*
    node * head1 = NULL;
    build(head1);
    display(head1);
    cout << "The two link list is " << same_length(head, head1) << endl;
    */
    
    return 0;
}
