#include "cs163_stack.h"


//These are the functions you will be implementing
//for this lab, using a linear linked list of arrays
//as the data structure

//Add a new item to the top of stack
int stack::push(const journal_entry & to_add)
{
            //Implement the function here
    if (!head || (head && top_index == MAX)) {
        node * curr = new node;
        curr->entries = new journal_entry [MAX];
        curr->next = head;
        head = curr;
        if (!head->entries[0].copy_entry(to_add))
            return 0;
        top_index = 1;
    }
    else
        if (!head->entries[top_index++].copy_entry(to_add))
            return 0;

    return 1;
}


//Remove the top of stack
int stack::pop (void)
{
            //Implement the function here
    if (!head)
        return 0;
    
    --top_index;
    if (top_index == 0) {
        head = head->next;
        top_index = 5;
    }

    return 1;
}


//Supply the journal at the top of stack back to the client
//Return 0 if there are no items
//top_index is one beyond where the top of stack is...
//with no items, top_index is zero
int stack::peek(journal_entry & found_at_top) const
{
    //Implement the function here
    if (!head || !found_at_top.copy_entry(head->entries[top_index-1]))
        return 0;
    return 1;
}
