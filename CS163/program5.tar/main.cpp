//Pengsheng Shi
//Program5
//program5 use LLL to improve the program that we have already did

#include "por5.h"
int main()
{
	cout << "Welcome to use activity list program." << endl;

	int choose;//store the choose of operation
	char match[21]; // store and compare the type of activity
	int total;
	//int count = 0;
	node * head = new node;
	head -> next = NULL;
	head -> category = NULL;
	do
	{
		cout << "What operation do you need:" << endl;
		cout << "1.Creat a new category" << endl;
		cout << "2.Do operation in a category" << endl;
		cin >> choose;
		cin.ignore(100, '\n');
		if (choose == 1)//do operation creat
		{
			if(head == NULL)
			{
				cout << "Enter the name of the category: ";
				head -> category = new char[21];
				cin.get(head -> category, 21, '\n');
				cin.ignore(100, '\n');
			}
			do{//build the LLL for different type
				node * current = new node;
				cout << "Enter the name of the category: ";
				current -> category = new char[21];
				cin >> current -> category; 
				cin.ignore(100, '\n');
				current -> next = head;  
				head = current;
			}while(head -> data.again());
		}
		else if (choose == 2)// do operation in the spcific type
		{
			node * temp = head;
			while(temp -> next)// show what type do we have
			{
				cout << temp -> category << ' ';
				temp = temp -> next;
				cout << endl;
			}
			cout << "Which type of activity do you want:" << endl;
			cin >> match;
			cin.ignore(100, '\n');
			node * current = head;
			while(current -> next)
			{
				int count = 0;
				if (strcmp(match, current -> category) == 0)//match the type and user entered
				{
					//int count = 0;
					do
					{
					   cout << "What operation do you need:" << endl;
					   cout << "1.Creat this activity list" << endl;
					   cout << "2.Display this list" << endl;
					   int choose1;
					   cin >> choose1;
					   cin.ignore(100, '\n');
					   if (choose1 == 1)
					   {
					   	   current -> data.total_item(total);
						   int i = 0;
						   do//input activity
						   {
							current -> data.infor_in(i);
							count += 1;
							++i;
							if(i >= total)
							   cout <<"List is full!" << endl;
						   }while(current -> data.again() && i<total);
					   }
					   else if (choose1 ==2)
						current -> data.display(count);
					   else 
						cout << "Please enter the number 1/2!" << endl;
					}while(current -> data.pro_again());
				}
				current = current -> next;
			}
		}
		else 
			cout << "Please enter the number 1/2" << endl;
	}while(head -> data.act_again());
	return 0;
}
