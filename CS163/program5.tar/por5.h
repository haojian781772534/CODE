//Pengsheng Shi
//program5


#include<iostream>
#include<cstring>
#include<cctype>

using namespace std;

struct activity
{
	char * name;
	char * desc;
	char * time;
	char * thing;
};

class activity_list
{
	public:
	   activity_list();
	   void infor_in(int & i);
	   void display(int count);
	   bool again();
	   bool pro_again();
	   bool act_again();
	   void total_item(int & total);
	   ~activity_list();

	private:
	   activity * act;
};


struct node
{
	activity_list data;
	char * category;
	node * next;
};
