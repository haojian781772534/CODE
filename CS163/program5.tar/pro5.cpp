//Pengsheng Shi
//program5
#include "por5.h"

activity_list :: activity_list()
{
	act = NULL;
}

activity_list :: ~activity_list()
{
	delete [] act;
}

void activity_list :: infor_in(int & i)//let user input information
{
	char word[100];
	cout << "Enter the No." << i <<" name of the activity:" << endl;
	cin.get(word, 100, '\n');
	cin.ignore(100, '\n');
	act[i].name = new char[strlen(word) + 1];
	strcpy(act[i].name, word);
	
	cout << "Enter the No." << i <<" description of the activity:" << endl;
	cin.get(word, 100, '\n');
	cin.ignore(100, '\n');
	act[i].desc = new char[strlen(word) + 1];
	strcpy(act[i].desc, word);

	cout << "Enter the No." << i <<" best time of the activity:" << endl;
	cin.get(word, 100, '\n');
	cin.ignore(100, '\n');
	act[i].time = new char[strlen(word) + 1];
	strcpy(act[i].time, word);

	cout << "Enter the No." << i <<" note of the activity:" << endl;
	cin.get(word, 100, '\n');
	cin.ignore(100, '\n');
	act[i].thing = new char[strlen(word) + 1];
	strcpy(act[i].thing, word);
}

void activity_list :: total_item(int & total)//ask user total number of activties and build array
{
	cout << "Enter the number of the activities:" << endl;
	cin >> total;
	cin.ignore(100, '\n');
	act = new activity[total + 1];
}

void activity_list :: display(int count)//display the list
{
	for(int i=0; i<count; ++i)
	{
		cout << "No. " << i << "activity:" << endl;
		cout << "Name: " << act[i].name << endl;
		cout << "Description: " << act[i].desc << endl;
		cout << "Best time of year: " << act[i].time << endl;
		cout << "Note: " << act[i].thing << endl << endl;
	}
}

bool activity_list :: again()
{
	char response;
	cout << "one more? Y/N" <<endl;
	cin >> response;
	cin.ignore(100, '\n');
	return toupper(response) == 'Y';
}

bool activity_list :: pro_again()
{
	char response;
	cout << "Do this program again? Y/N" <<endl;
	cin >> response;
	cin.ignore(100, '\n');
	return toupper(response) == 'Y';
}

bool activity_list :: act_again()
{
	char response;
	cout << "DO you need to do operation again about category?" << endl;
	cin >> response;
	cin.ignore(100, '\n');
	return toupper(response) == 'Y';
}
